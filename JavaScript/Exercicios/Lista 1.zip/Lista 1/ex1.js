// 1.	Escreva um programa que declare duas variáveis numéricas e realize as quatro
// operações matemáticas básicas (+, -, *, /). Imprima os resultados no console.

{
  let x = 1;
  let y = 5;

  let soma = x + y;
  let subtracao = x - y;
  let multiplicacao = x * y;
  let divisao = x / y;

  console.log(soma);
  console.log(subtracao);
  console.log(multiplicacao);
  console.log(divisao);
}

// 2.	Faça um programa que mostre os números impares em um intervalo de 0 a 100.

for (let i = 0; i <= 100; i++) {
  if (i % 2 == 1) {
    console.log(i);
  }
}

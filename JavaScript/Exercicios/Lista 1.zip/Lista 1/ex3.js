// 3.	Faça um programa que mostre a quantidade de caracteres
// para o texto “Disciplina de Programação para web”.

const nome = "Disciplina de Programação para web";

console.log(nome.length);
